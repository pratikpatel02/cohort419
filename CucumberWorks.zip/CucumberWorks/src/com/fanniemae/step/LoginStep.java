package com.fanniemae.step;

import java.util.List;
import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStep {

	@Given("^Browser is open$")
	public void browser_is_open() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println("Launching Browser......");
	}

	@When("^user name and password is entered$")
	public void user_name_and_password_is_entered(DataTable datatable) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("user name and password goes here......");
		
		List<Map<String, String>> datalist = datatable.asMaps(String.class, String.class);
		
		for(Map<String,String> temp : datalist){
			System.out.println("User name " + temp.get("username"));
			System.out.println("Password " + temp.get("password"));
			System.out.println("Designation " + temp.get("designation"));
		}
	}

	@When("^click on submit$")
	public void click_on_submit() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Submit the form......");
		
	}

	@Then("^validate the user detail$")
	public void validate_the_user_detail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Validation code goes here......");
	}

	
}
