package com.fanniemae.step;

import cucumber.api.java.en.*;

public class LoanSanctionStep {


	@Then("sanction loan")
	public void sanction_loan() {
		System.out.println("sanction loan");
	}

	//* + ? .
	@Given("the customer works ([A-Za-z]{1,}) time$")
	public void the_customer_works_full_time(String worktype) {
		System.out.println("the customer works "+worktype+ "time");
	}
	
	@And("^working in  ([A-Za-z]{1,}) office$")
	public void working_in_private_office(String workoffice) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("working in "+workoffice+"office>>>>>>>>");
	}
	
	@But("customer has to replay with in (\\d+) years$")
	public void customer_has_to_replay_with_in_20_years(int arg1) {
		System.out.println("customer has to replay with in "+arg1+"years");
	}
	
	@When("^customer has credit score of (\\d+)$")
	public void customer_has_credit_score_of(int arg1){
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("customer has credit score of>>>>>>>>");
	}
	
//	@And("working in govt office")
//	public void working_in_govt_office() {
//		System.out.println("working in govt office");
//	}

//	@Given("^the customer works part time$")
//	public void the_customer_works_part_time() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//	    System.out.println("the customer works part time>>>>>>>>");
//	}
	//@When("^customer has credit score of (\\d+)$")
//	public void customer_has_credit_score_of(int arg1) throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("customer has credit score of>>>>>>>>");
//	}
////	
}
