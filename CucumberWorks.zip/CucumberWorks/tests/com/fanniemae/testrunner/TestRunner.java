package com.fanniemae.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(
			features={"features/com/fanniemae/features"}, 
			glue={"com.fanniemae.step"},
			plugin={"pretty", "html:target/cucumber-html-rpt"},
			monochrome=true,
			//tags = {"~@Sanity"}
			//tags = {"@Sanity,@Smoke"}		//run selective features...
			tags = {"~@Smoke"}
		)
//The TestRunner class will act as a place holder
//for execution
public class TestRunner {


}
